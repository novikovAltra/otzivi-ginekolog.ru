<?php
include_once dirname(__FILE__).'/setting.inc.php';
$_lang['msimport_caption'] = 'Импорт';
$_lang['msimport_menu_desc'] = 'Импорт товаров из xlsx';