<?php
/**
 *  * Base controller file
 *
 * @category  Maintenance
 * @author    S. Hamblett <steve.hamblett@linux.com>
 * @copyright 2009 S. Hamblett
 * @license   GPLv3 http://www.gnu.org/licenses/gpl.html
 * @link      none
 * 
 * @package janitor
 */

return include dirname(__FILE__).'/controllers/index.php';
