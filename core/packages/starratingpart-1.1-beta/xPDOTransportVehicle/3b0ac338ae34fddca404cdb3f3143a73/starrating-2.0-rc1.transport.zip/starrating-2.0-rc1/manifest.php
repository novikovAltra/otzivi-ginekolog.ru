<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '08df2fdd59736bbaf3f932e376508543',
      'native_key' => 'starrating',
      'filename' => 'modNamespace/36d8bfa83baaf696daaaa1d1e7fab353.vehicle',
      'namespace' => 'starrating',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '74eedeef39216c2b53cb50d949bf4f58',
      'native_key' => 1,
      'filename' => 'modCategory/0aaf03ba91c7c760d4385b23514ee310.vehicle',
      'namespace' => 'starrating',
    ),
  ),
);