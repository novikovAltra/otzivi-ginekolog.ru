<?php
require_once (dirname(dirname(__FILE__)) . '/ticketqueue.class.php');
class TicketQueue_mysql extends TicketQueue {}