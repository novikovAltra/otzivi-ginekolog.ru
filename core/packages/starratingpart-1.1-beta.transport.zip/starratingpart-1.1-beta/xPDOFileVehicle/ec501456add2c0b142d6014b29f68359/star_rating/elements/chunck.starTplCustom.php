<div class="star_wrapper">
    [[+active:is=`1`:then=`Оцеите статью:`:else=`Оценка читателей:`]]
    <div class='star-rating-wrapp'>[[+rating]]</div>
    [[+active:is=`1`:then=``:else=` Спасибо за ваш голос!`]]
</div>
<!--span class="totalvotes">Votes: [[-+vote_count]]</span-->