<?php
/**
* migx
*
* @package migx
* @language it
*/


$_lang['mig.tabs'] = 'Schede form';
$_lang['mig.columns'] = 'Colonne della Griglia';
$_lang['mig.btntext'] = 'Testo alternativo ad "Aggiungi Elemento"';
$_lang['mig.previewurl'] = 'Url Anteprima';
$_lang['mig.jsonvarkey'] = 'JsonVarKey Anteprima';
$_lang['mig.configs'] = 'Configurazioni';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';