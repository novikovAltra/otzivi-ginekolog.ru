<?php
require_once (dirname(dirname(__FILE__)) . '/ticketview.class.php');
class TicketView_mysql extends TicketView {}