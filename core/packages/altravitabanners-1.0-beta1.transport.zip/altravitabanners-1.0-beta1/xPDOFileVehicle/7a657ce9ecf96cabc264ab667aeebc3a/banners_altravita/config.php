<?php
return array(
    "show_banner_on_main" => 1,
    "show_banner_on_article" => 1
);