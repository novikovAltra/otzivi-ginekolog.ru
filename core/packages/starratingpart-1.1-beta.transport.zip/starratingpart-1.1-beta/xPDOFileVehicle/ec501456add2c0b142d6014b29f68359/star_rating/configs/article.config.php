<?php
return array(
    'firstStarTpl' => 'firstStarTpl',
    'activeStarTpl' => 'activeStarTpl',
    'disableStarTpl' => 'disableStarTpl',
    'listStarTpl' => 'listStarTpl',
    'starTpl' => 'starTplCustom',
    'groupId' => 1
);