
Janitor component for MODx Revolution

Purpose: Assists in common site maintenance tasks.
Author: S. Hamblett steve.hamblett@linux.com
For: MODx CMS (www.modxcms.com) Revolution
Date: 18/08/2010

Ideas and suggestions contributed by MODx members, Henrik Nielsen, BobRay and charliez

Janitor is licensed under the GPL, 3rd party components however are licensed
seperetely, please see individual 3rd party applications for further details.

See the user guide for further details on how to use this component.


